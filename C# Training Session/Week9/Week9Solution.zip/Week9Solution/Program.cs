﻿using System;

namespace Week9Solution
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Student account
            User user1;
            user1.name = "Billy";
            user1.role = "Student";

            //Teacher account
            User user2;
            user2.name = "Susan";
            user2.role = "Teacher";

            //Add both users to the app.
            GradeEntryApp app = new GradeEntryApp();
            app.AddUser(user1);
            app.AddUser(user2);

            //Student's cant enter grades, will give an error in console.
            app.Login("Billy");
            app.Grade = "A+";

            //Teachers can enter grades, this will show a success message in console.
            app.Login("Susan");
            app.Grade = "C-";

            //This login will fail because it has an invalid username
            app.Login("Carl");
        }
    }
}
