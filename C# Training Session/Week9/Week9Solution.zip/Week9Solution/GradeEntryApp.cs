﻿using System;
using System.Collections.Generic;
/// <summary>
/// Summary description for GradeEntryApp
/// </summary>
/// 
namespace Week9Solution
{
	public class GradeEntryApp
	{
        //This property enables anyone to access a grade but only the teacher can set the grade.
		private string grade;
		public string Grade { get
            {
                return grade; 
            } set
            {
                Console.WriteLine("\n-----Grade Edit Request Sent----");
                if (currentUser.role == "Teacher")
                {
                    grade = value;
                    Console.WriteLine("Grade was successfully updated to: " + grade);
                } else
                {
                    Console.WriteLine("Only Teachers Can Edit Grades!");
                }
                Console.WriteLine("---Grade Edit Request Ended----\n");
            }
        }

        
		List<User> users = new List<User>();
		private User currentUser;

        //If we don't already have the user in our list, add it to it!
		public void AddUser(User newUser)
        {
			if (!users.Contains(newUser))
            {
				users.Add(newUser);
			} else
            {
                Console.WriteLine("The user already exists!");
            }
        }

        //Switches the active to user to a specified user and throws error if you don't give a valid user.
		public void Login(string userName)
        {
            Console.WriteLine("\n-----New Login Attempt------");
            //This clears out the original user data if someone is already logged in.
            currentUser = new User();  

            //This loop checks each user for their name to match the parameter.
            foreach (User user in users)
            {
				if (user.name == userName)
                {
                    currentUser = user;
                    Console.WriteLine($"{user.name} was succesfully logged in");
                }
            }

            //If the current user's name is still empty after the loop, that means no one was found, throw an error.
            if (currentUser.name == null)
            {
                Console.WriteLine("No user with the given name was found to login, please add that user");
            }

            Console.WriteLine("---Login Attempt Ended----\n");
        }
	}
}
