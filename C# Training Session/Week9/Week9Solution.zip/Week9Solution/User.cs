﻿using System;


namespace Week9Solution
{
    public struct User
    {
        public string name;
        public string role;
    }
}
